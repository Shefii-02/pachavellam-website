@php 
    $title = "Login/Signup";
@endphp

@extends('layouts.kpsc-app')
@section('title', $title ?? "KPSC")

@section('styles')

<style>

body {
    max-height: 100vh;
}

.frame {
    min-height: 600px;
    /*width: 420px;*/
       background-color:#e9ecefa8;
    margin-left: auto;
    margin-right: auto;
    border-top: solid 1px rgba(255, 255, 255, .5);
    border-radius: 15px;
    box-shadow: 0px 2px 7px rgba(0, 0, 0, 0.2);
    overflow: hidden;
    transition: all .5s ease
      text-shadow: 0 0 3px #FF0000;
}

.frame-long {
    min-height: 615px
}

.frame-short {
    min-height: 400px;
    margin-top: 50px;
    box-shadow: 0px 2px 7px rgba(0, 0, 0, 0.1)
}

.nav {
    width: 100%;
    height: 100px;
    padding-top: 40px;
    opacity: 1;
    transition: all .5s ease
    display: flex;
    justify-content: center;
     background: url(https://images.unsplash.com/photo-1617957718587-60a442884bee) no-repeat center center;
    background-size: cover;
}

.nav-up {
    transform: translateY(-100px);
    opacity: 0
}

li {
    padding-left: 10px;
    font-size: 18px;
    display: inline;
    text-align: left;
    padding-right: 10px;
    color: #000000
}

.signin-active a {
    padding-bottom: 10px;
    color: #000000;
    text-decoration: none;
    border-bottom: solid 2px #1059FF;
    transition: all .25s ease;
    cursor: pointer
}

.signin-inactive a {
    padding-bottom: 0;
    color: #ffffff;
    text-decoration: none;
    border-bottom: none;
    cursor: pointer
}

.signup-active a {
    cursor: pointer;
    color: #ffffff;
    text-decoration: none;
    border-bottom: solid 1px #1059FF;
    padding-bottom: 10px
}

.signup-inactive a {
    cursor: pointer;
    color: #ffffff;
    text-decoration: none;
    transition: all .25s ease
}

.form-signin {
    /*width: 430px;*/
    min-height: 375px;
    font-size: 16px;
    font-weight: 300;
    padding-left: 10px;
    padding-right: 10px;
    padding-top: 10px;
    transition: opacity .5s ease, transform .5s ease
}

.form-signin-left {
    transform: translateX(-400px);
    opacity: .0
}

.form-signup{
    font-size: 12px;
    font-weight: 300; 
    padding-left: 10px;
    padding-right: 10px;
    transition: all .5s ease;
    margin-bottom:50px;
}




#check path {
    stroke: #ffffff;
    stroke-linecap: round;
    stroke-linejoin: round;
    stroke-width: .85px;
    stroke-dasharray: 60px 300px;
    stroke-dashoffset: -166px;
    fill: rgba(255, 255, 255, .0);
    transition: stroke-dashoffset 2s ease .5s, fill 1.5s ease 1.0s
}

#check.checked path {
    stroke-dashoffset: 33px;
    fill: rgba(255, 255, 255, .03)
}

.form-signin input,
.form-signup input {
    color: #000000;
    font-size: 15px
}

.form-styling {
    width: 100%;
    height: 35px;
    padding-left: 15px;
    border: none;
    border-radius: 20px;
    margin-bottom: 10px;
    background: rgba(255, 255, 255, .2);
    border: 1px solid #cbc2c2e3;
}

label {
    
    font-weight: 800;
    font-size: 14px;
    padding-left: 15px;
    color: rgb(0 0 0 / 70%);
}

:focus {
    outline: none
}

.form-signin input:focus,
textarea:focus,
.form-signup input:focus,
textarea:focus {
    background: rgba(255, 255, 255, .3);
    border: none;
    padding-right: 40px;
    transition: background .5s ease
}

[type="checkbox"]:not(:checked),
[type="checkbox"]:checked {
    position: absolute;
    display: none
}

[type="checkbox"]:not(:checked)+label,
[type="checkbox"]:checked+label {
    position: relative;
    padding-left: 85px;
    padding-top: 2px;
    cursor: pointer;
    margin-top: 8px
}

[type="checkbox"]:not(:checked)+label:before,
[type="checkbox"]:checked+label:before,
[type="checkbox"]:not(:checked)+label:after,
[type="checkbox"]:checked+label:after {
    content: '';
    position: absolute
}

[type="checkbox"]:not(:checked)+label:before,
[type="checkbox"]:checked+label:before {
    width: 65px;
    height: 30px;
    background: #0000008a;
    border-radius: 15px;
    left: 0;
    top: -3px;
    transition: all .2s ease
}

[type="checkbox"]:not(:checked)+label:after,
[type="checkbox"]:checked+label:after {
    width: 10px;
    height: 10px;
    background: rgba(255, 255, 255, .7);
    border-radius: 50%;
    top: 7px;
    left: 10px;
    transition: all .2s ease
}

[type="checkbox"]:checked+label:before {
    background: #0F4FE6
}

[type="checkbox"]:checked+label:after {
    background: #ffffff;
    top: 7px;
    left: 45px
}

[type="checkbox"]:checked+label .ui,
[type="checkbox"]:not(:checked)+label .ui:before,
[type="checkbox"]:checked+label .ui:after {
    position: absolute;
    left: 6px;
    width: 65px;
    border-radius: 15px;
    font-size: 14px;
    font-weight: bold;
    line-height: 22px;
    transition: all .2s ease
}

[type="checkbox"]:checked+label .shw,
[type="checkbox"]:not(:checked)+label .shw:before,
[type="checkbox"]:checked+label .shw:after {
    position: absolute;
    left: 6px;
    width: 65px;
    border-radius: 15px;
    font-size: 14px;
    font-weight: bold;
    line-height: 22px;
    transition: all .2s ease
}

[type="checkbox"]:checked+label .shw2,
[type="checkbox"]:not(:checked)+label .shw2:before,
[type="checkbox"]:checked+label .shw2:after {
    position: absolute;
    left: 6px;
    width: 65px;
    border-radius: 15px;
    font-size: 14px;
    font-weight: bold;
    line-height: 22px;
    transition: all .2s ease
}


[type="checkbox"]:not(:checked)+label .ui:before {
    content: "No";
    left: 32px;
    color: rgba(255, 255, 255, .7)
}


[type="checkbox"]:not(:checked)+label .shw:before,[type="checkbox"]:not(:checked)+label .shw2:before {
    content: "Hide";
    left: 32px;
    color: rgba(255, 255, 255, .7)
}



[type="checkbox"]:checked+label .ui:after {
    content: "Yes";
    color: #ffffff
}

[type="checkbox"]:checked+label .shw:after,[type="checkbox"]:checked+label .shw2:after {
    content: "Show";
    color: #ffffff
}


[type="checkbox"]:focus+label:before {
    box-sizing: border-box;
    margin-top: -1px
}

.btn-signup {
    float: left;
    font-weight: 700;
    text-transform: uppercase;
    font-size: 13px;
    text-align: center;
    color: #ffffff;
    padding-top: 8px;
    width: 100%;
    height: 35px;
    border: none;
    border-radius: 20px;
    margin-top: 23px;
    background-color: #1059FF
}

.btn-signin {
    float: left;
    padding-top: 8px;
    width: 100%;
    height: 35px;
    border: none;
    border-radius: 20px;
    margin-top: -8px
}

.btn-animate {
    float: left;
    font-weight: 700;
    font-size: 13px;
    text-align: center;
    color: rgba(255, 255, 255, 1);
    padding-top: 8px;
    width: 100%;
    height: 35px;
    border: none;
    border-radius: 20px;
    margin-top: 23px;
    background-color: rgba(16, 89, 255, 1);
    left: 0px;
    top: 0px;
    transition: all .5s ease, top .5s ease .5s, height .5s ease .5s, background-color .5s ease .75s
}

.btn-animate-grow {
    width: 130%;
    height: 625px;
    position: relative;
    left: -55px;
    top: -420px;
    color: rgba(255, 255, 255, 0);
    background-color: rgba(255, 255, 255, 1)
}

.btn-signup:hover,
.btn-signin:hover {
    cursor: pointer;
    background-color: #0F4FE6;
    transition: background-color .5s
}

.forgot {
    height: 100px;
    width: 80%;
    margin-left: auto;
    margin-right: auto;
    text-align: center;
    padding-top: 24px;
    margin-top: -535px;
    /*border-top: solid 1px rgba(255, 255, 255, .3);*/
    transition: all 0.5s ease
}

.forgot-left {
    transform: translateX(-400px);
    opacity: 0
}

.forgot-fade {
    opacity: 0
}

.forgot a {
    color: rgba(255, 255, 255, .3);
    font-weight: 400;
    font-size: 13px;
    text-decoration: none
}



.welcome-left {
    transform: translateY(-780px);
    opacity: 1
}

.cover-photo {
    height: 150px;
    position: relative;
    left: 0px;
    top: -900px;
    background: linear-gradient(rgba(35, 43, 85, 0.75), rgba(35, 43, 85, 0.95)), url(https://img.icons8.com/bubbles/100/000000/user.png);
    background-size: cover;
    opacity: 0;
    transition: all 1.5s ease 0.55s
}

.cover-photo-down {
    top: -575px;
    opacity: 1
}

.profile-photo {
    height: 50px;
    width: 50px;
    position: relative;
    border-radius: 70px;
    transition: top 1.5s ease 0.35s, opacity .75s ease .5s;
    border: solid 3px #ffffff
}



.btn-goback {
    position: relative;
    margin-right: auto;
    top: -400px;
    float: left;
    padding: 8px;
    width: 83%;
    margin-left: 37px;
    margin-right: 37px;
    height: 35px;
    border-radius: 20px;
    font-weight: 700;
    font-size: 13px;
    text-align: center;
    color: #1059FF;
    margin-top: -8px;
    border: solid 1px #1059FF;
    opacity: 0;
    transition: top 1.5s ease 0.35s, opacity .75s ease .5s
}

.btn-goback-up {
    top: -1080px;
    opacity: 1
}

.btn-goback:hover {
    cursor: pointer;
    background-color: #0F4FE6;
    transition: all .5s;
    color: #ffffff
}
.fileUpload {
    position: relative;
    overflow: hidden;
    margin: 10px;
}
.fileUpload input.upload {
    position: absolute;
    top: 0;
    right: 0;
    margin: 0;
    padding: 0;
    font-size: 20px;
    cursor: pointer;
    opacity: 0;
    filter: alpha(opacity=0);
}
</style>
@endsection

@section('content')
  <div class="preloader" id="preloader" style="display:none">
      <div class="spinner-grow text-secondary" role="status">
        <div class="sr-only">Loading...</div>
      </div>
    </div>
<div class="page-content-wrapper">
    <!-- Element Wrapper-->
    <div class="element-wrapper">
    	<div class="container">
            <div class="d-flex justify-content-center">
                <div class="col-lg-4">
                    <div class="frame">
                        <div class="nav">
                            <ul class="links d-flex">
                                <li class="signin-active"><a class="btn-nav ">Existing User</a></li>
                                <li class="signup-inactive"><a class="btn-nav ">New User</a></li>
                            </ul>
                        </div>
                        <div ng-app ng-init="checked = false">
                          @if ($errors->any())
                                @foreach ($errors->all() as $error)
                                    <div class="alert alert-danger">
                                       {{ $error }}
                                    </div>
                                @endforeach
                            @endif
                            
                            <form class="form-signin mb-5" action="{{route('sign-in-check')}}" method="POST" name="form"> 
                            @csrf()
                            @if(session()->has('message'))
                                <div class="alert alert-danger">
                                {{ session()->get('message') }}
                                </div>
                            @endif
                                <label for="fullname">Email Id</label>
                                <input class="form-styling"  type="email" name="email" value="{{ old('email')}}"  autocomplete="off" required placeholder="example@gmail.com" /> 
                                <label for="password">Password </label> 
                                <span class="float-right mb-2">
                                     <!--<input type="checkbox" id="logn_show_password"  /> -->
                                     <!--<label for="logn_show_password">-->
                                     <!--    <span class="shw"></span>-->
                                     <!--</label>-->
                                     <i class="fa  fa-eye-slash" style="cursor: pointer;" onclick="shw_password()" id="togglePassword"></i>

                                </span>
                                
                                <input class="form-styling shw_password" type="password" value="{{ old('password')}}" name="password"
                                autocomplete="new-password" required placeholder="******"  /> 
                                
                                <input type="checkbox" id="keep_login" /> 
                                <label for="keep_login"><span class="ui"></span>Keep me signed in</label>
                                <div class="btn-animate mb-4"> 
                                    <button type="submit" class="btn-signin btn btn-secondary">Login to your account</button>
                                </div>
                                
                              <div class="mt-5 mb-3 text-right"> <a href="#"  data-toggle="modal" data-target="#forget_password" class="text-dark font-bold">Forgot your password?</a> </div>
                              		<!-- Social buttons and divider -->
    							<div class="row">
    								<!-- Divider with text -->
    								<div class="col-12 m-1 text-center">
    									<hr>
    									<p class=" text-center text-dark font-weight-bold">Or login with single click</p>
    								</div>
    
    								<!-- Social btn -->
    								<div class="col-12 d-grid text-center">
    									<a style="    border: 1px solid #e6e6e6;" href="{{ route('auth.google') }}" class="btn bg-light text-dark mb-xxl-0">
    										<img src="https://colorlib.com/etc/lf/Login_v11/images/icons/icon-google.png"></i>
    										&nbsp; 
    										Google
    									</a>
    								</div>
    								<!-- Social btn -->
    								{{--
    								<div class="col-6 d-grid text-center">
    									<a style="    border: 1px solid #e6e6e6;" href="{{ route('auth.facebook') }}" class="btn text-dark bg-light ">
    										<img width="30px" src="https://images.g2crowd.com/uploads/vendor/image/492/large_detail_0f38b80ca04c245e0c4383c048a59bd2.png"></img>
    										&nbsp; 
    										Facebook
    									</a>
    								</div>--}}
    							</div>
                           </form>
                            <form class="form-signup d-none mb-5" action="{{url('kpsc/daily-exam/register')}}" method="POST" name="form1"> 
                            @csrf()
                            
                                  <div class="row">
    								<!-- Divider with text -->
    								<div class="col-12 m-1 text-center">
    									<hr>
    									<p class=" text-center  text-dark font-weight-bold">
    									    Register your account  using in a single click</p>
    								</div>
    
    								<!-- Social btn -->
    								<div class="col-12 d-grid text-center">
    									<a style="    border: 1px solid #e6e6e6;" href="{{ route('auth.google') }}" class="btn bg-light text-dark mb-xxl-0">
    										<img src="https://colorlib.com/etc/lf/Login_v11/images/icons/icon-google.png"></i>
    										&nbsp; 
    										Google
    									</a>
    								</div>
    								<!-- Social btn -->
    						{{--		<div class="col-6 d-grid text-center">
    									<a style="    border: 1px solid #e6e6e6;" href="{{ route('auth.facebook') }}" class="btn text-dark bg-light ">
    										<img width="30px" src="https://images.g2crowd.com/uploads/vendor/image/492/large_detail_0f38b80ca04c245e0c4383c048a59bd2.png"></img>
    										&nbsp; 
    										Facebook
    									</a>
    								</div>--}}
    							</div>
    							
    								<!-- Divider with text -->
    								<div class="col-12 m-1">
    									<hr>
    									<p class=" text-center translate-middle text-dark font-weight-bold">Or Register  using below form</p>
    								</div>
                            
                                <div class="col-lg-12 text-center">
                                    <div class="fileUpload">
                                            <img src="https://img.icons8.com/bubbles/100/000000/user.png" id="uploaded-image" class="profile-photo">
                                            <input accept="image/*" id="pic1" type="file" class="upload" />
                                            <input type="hidden" name="image" id="picture" />
                                            <label for="pic1" class="mt-2">
                                                Choose Profile Pic</label>
                                            <br>
                                                <span class="text-dark">[profile photo showing in leaderboard]</span>  
                                    </div>
                                </div>
                                <label for="fullname">Full name</label>
                                <input class="form-styling" type="text" value="{{ old('name')}}" required autocomplete="off"  name="name" placeholder="" />
                                <label for="email">Email
                                 <br> <span class="text-dark">[resetting password for use your email id]</span>          
                                 </label>
                                <input class="form-styling" type="text"  value="{{ old('email')}}" autocomplete="off"  required name="email" placeholder="" />
                                
                                <label for="dlno">Mobile Number (without countrycode [91,0,+91])
                                        <br>
                                       <span>
                                          [ for OTP verification ]
                                       </span>
                                 </label>
                                <input class="form-styling" type="text" autocomplete="off" required  name="mobile_no" placeholder="" value="{{ old('mobile_no')}}"  onkeypress="return /[0-9]/i.test(event.key)"  maxlength="10" /> 
                                
                                <label for="password">Create password</label>  
                                    
                                <input class="form-styling " type="text" required autocomplete="new-password" name="password" placeholder="" />
                                   
                                
                                <button type="submit" class="btn-signin btn btn-secondary mt-3 mb-5">Register  your account</button>
        
                         
                            </form>
                            
                        </div>
                    </div>
                </div>
           
               
            </div> 
             <!-- Ads -->
            {!! single_ads_show() !!}
             <!-- Ads -->
            {!! single_ads_show() !!}
        </div>
    	</div>
    </div>

  <div class="modal uploadimageModal" tabindex="-1" role="dialog" id="uploadimageModal">
    <div class="modal-dialog" role="document" >
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"> Image</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12 text-center">
                        <div class="image_demo"></div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="preview_target" value="" />
                <input type="hidden" id="input_target" value="" />
                <button type="button" class="btn btn-primary crop_image">Crop and Save</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div> 



<!-- Modal -->
<div class="modal fade" id="forget_password" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Forget Your Password?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="alert_result"></div>
            <form action="{{url('kpsc/daily-exam/forget-password')}}" method="POST" id="forget__password">
                @csrf()
                  <div class="form-group">
                    <label for="for_email_id" class="text-dark">Existing Email Id</label>
                    <input type="email" class="form-control" name="email_id" required autocomplete="off" id="for_email_id">
                  </div>
                  <div class="form-group">
                    <label for="for_mobile_no" class="text-dark">Existing Mobile Number</label>
                    <input type="text" class="form-control" name="mobile" required autocomplete="off" id="for_mobile_no"  onkeypress="return /[0-9]/i.test(event.key)"  maxlength="10" >
                  </div>
                  <div class="form-group">
                    <label for="for_password" class="text-dark">Create New Password</label>
                    
                                
                    <input type="text" class="form-control" name="password" required autocomplete="new-password" id="for_password">
                  </div>
                 
                    <div class="text-right">
                      <span  class="btn btn-secondary" data-dismiss="modal">Close</span>
                      <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                 </div>
            </form>
      </div>
    </div>
  </div>
</div>


@endsection
@section('scripts')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.css" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Dropify/0.2.2/js/dropify.js"></script>

<script>
    $(function() {
        $(".btn-nav").click(function() {
            $(".form-signin").toggleClass("d-none");
            $(".form-signup").toggleClass("d-block");
            // $(".frame").toggleClass("frame-long");
            $(".signup-inactive").toggleClass("signup-active");
            $(".signin-active").toggleClass("signin-inactive");
            $(this).removeClass("idle").addClass("active");
        });
    });
    
   
    var image_crop = $('.image_demo').croppie({
        viewport: {
            width: 100,
            height: 100,
            type: 'circle'
        },
        boundary: {
            width: 100,
            height: 100
        }
    });
// /// catching up the cover_image change event and binding the image into my croppie. Then show the modal.
    $('#pic1').on('change', function() {
        var reader = new FileReader();
        reader.onload = function(event) {
            image_crop.croppie('bind', {
                url: event.target.result,
            });
        }
        reader.readAsDataURL(this.files[0]);
        $('#uploadimageModal').modal('show');
       
    });


    $('.crop_image').click(function(event) {
        image_crop.croppie('result', {
            type: 'canvas',
            format: 'png'
        }).then(function(response) {
            $("#uploaded-image").attr("src", response);
            $("#picture").val(response);
        });
        $("#pic1").val("");
        $('#uploadimageModal').modal('hide');
    });

    $(document).on('submit', '#forget__password', function(e) {
        e.preventDefault();
        var url = $(this).attr('action');
        var postData = $(this).serializeArray();
        var alert2;
        $('.preloader').show();
        $.ajax(
            {
                url : url,
                type: "POST",
                data : postData,
                success:function(data) 
                {
                $('.preloader').hide();
                   if(data.trim() === '0'){
                        alert2 = `<div class="alert bg-danger text-dark alert-dismissible fade show" role="alert">
                                      <strong>Invalid Attempt!</strong> Your Enter Details Incorrceted
                                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>`;
                        
                    }
                    else{
                         alert2 = `<div class="alert bg-dark text-dark alert-dismissible fade show" role="alert">
                                      <strong>Awesome!</strong> Your Password Changed..
                                      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                      </button>
                                    </div>`;
                                    $("#for_email_id").val('');
                                    $("#for_mobile_no").val('');
                                    $("#for_password").val('');
                                    $("#for_confirm").val('');
                    }
                    
                    $('.alert_result').html(alert2);
                
                }
            });
        
    });
    
    
    $('body').on('click', '#togglePassword', function(e) {
        
        var x  = $('.shw_password').attr('type');
        if (x === "password") {
            $('.shw_password').attr('type','text');
            $(this).attr('class','fa fa-eye')
        } else {
            $('.shw_password').attr('type','password');
            $(this).attr('class','fa fa-eye-slash')
        }
    });
    


 

</script>
@endsection